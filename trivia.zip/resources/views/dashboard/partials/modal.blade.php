<div id="myModalDelete" class="modal fade" style="color:black" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Confirmation</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body" align="center">
            	<p>Are you sure want to delete <b id="text"></b> ?</p>
            </div>
            <div class="modal-footer" align="center">
                <button type="button" class="btn btn-primary waves-effect" data-dismiss="modal">No</button>
                <a id="btnYes" class="btn btn-danger">Yes</a>
            </div>
        </div>
    </div>
</div>