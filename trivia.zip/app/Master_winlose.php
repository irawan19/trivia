<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Master_winlose extends Model
{
    public $timestamps = false;
    protected $table = 'master_winloses';
}
