<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Master_feature extends Model
{
    public $timestamps = false;
    protected $table = 'master_features';
}
