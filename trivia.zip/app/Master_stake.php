<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Master_stake extends Model
{
    public $timestamps = false;
    protected $table = 'master_stakes';
}
