<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Master_app_configuration extends Model
{
    public $timestamps = false;
    protected $table = 'master_app_configurations';
}
