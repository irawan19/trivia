<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Master_game extends Model
{
    public $timestamps = false;
    protected $table = 'master_games';
}
