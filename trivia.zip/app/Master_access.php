<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Master_access extends Model
{
    public $timestamps = false;
    protected $table = 'master_accesses';
}
