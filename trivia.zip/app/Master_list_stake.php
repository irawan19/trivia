<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Master_list_stake extends Model
{
    public $timestamps = false;
    protected $table = 'master_list_stakes';
}
