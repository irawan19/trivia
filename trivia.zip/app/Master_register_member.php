<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Master_register_member extends Model
{
    public $timestamps = false;
    protected $table = 'master_register_members';
}
